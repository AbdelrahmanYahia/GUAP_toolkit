#!/usr/bin/python3
import sys
import os

GUAP_DIR = (os.path.abspath(__file__)).replace("GUI.py","")
sys.path.append(f"{GUAP_DIR}/")

from UI.UI_app import GUAP_GUI


if __name__ == "__main__":
    app = GUAP_GUI()
    app.start()
