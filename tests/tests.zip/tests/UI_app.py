import customtkinter
from UI.UI_elements import *

# Main App class
class GUAP_GUI(customtkinter.CTk):
    WIDTH = 1200
    HEIGHT = 700
    

    def __init__(self):
        super().__init__()

        # main UI elements
        self.title("GUAP")
        self.geometry(f"{GUAP_GUI.WIDTH}x{GUAP_GUI.HEIGHT}")
        self.protocol("WM_DELETE_WINDOW", self.on_closing) # call .on_closing() when app gets closed
       
       # create side frame 
        self.side_frame =  Side_frame(self, corner_radius=5)
        self.side_frame.grid(row=0, column=0, columnspan=2, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create config_frame
        self.config_frame = config_frame(self,corner_radius=5)
        self.config_frame.grid(row=0, column=2, columnspan=6, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create options_frame
        # self.options_frame = customtkinter.CTkFrame(self,corner_radius=5)
        # self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nsew",padx=5, pady=5)

        # create Statusbar frame
        self.statusbar_frame = status_bar(self,corner_radius=5)
        self.statusbar_frame.grid(row=11, column=0, columnspan=20, rowspan=1, sticky= W+E,padx=5, pady=5)
        global statusbar
        statusbar = self.statusbar_frame

        # create log_frame
        self.log_frame = Log_frame(self)
        self.log_frame.grid(row=0,column=10, columnspan=8, rowspan=11, sticky="nswe",padx=5, pady=5)
        global log_frame
        log_frame = self.log_frame
        #================ configure status bar ===============

        # grid configure
        self.grid_columnconfigure(15,weight=1)
        self.grid_rowconfigure(8,weight=1)

    def on_closing(self, event=0):
        self.destroy()

    def start(self):
        self.mainloop()

    def change_mode(self):
        if self.side_frame.change_theme_switch.get() == 1:
            customtkinter.set_appearance_mode("dark")
            Log_frame.update_log(self.log_frame,"Mode changed to dark")
        else:
            customtkinter.set_appearance_mode("light")
            Log_frame.update_log(self.log_frame,"Mode changed to light")

    def set_options_frame(self,frame):
        self.options_frame = frame
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nsew",padx=5, pady=5)
