#!/usr/bin/python3

# import packages 
import multiprocessing
import customtkinter
import sys
import logging
import psutil
from datetime import datetime
from datetime import date
import platform
from UI.UI_app import *

use_QIIME2 = True
# set theme in Customtkinter
customtkinter.set_appearance_mode("Light")  # Modes: "System" (standard), "Dark", "Light"
# customtkinter.set_default_color_theme("/home/abdelrahman/Desktop/GUAP_GUI/bin/custom_theme.json")

all_threads = multiprocessing.cpu_count()
platform_ = str(platform.system())


if all_threads < 4:
    logging.error(f"\033[;31;1mYour System doesn't have enough threads to run the analyis")
    exit(1)
all_mem =int( (psutil.virtual_memory().total ) / 1000000000 )
if all_mem < 7:
    logging.error(f"\033[;31;1mYour System doesn't have enough memory to run the analyis")
    exit(1)

today = date.today()
d1 = today.strftime("%d-%b-%Y")
now = datetime.now()
current_time = now.strftime("%H:%M:%S")

system_info = f"""{d1}    GUAP GUI started at   {current_time}

System platform:   {platform_}
total threads:      {all_threads}
total memory:     {all_mem}

"""

# stores all vars inside a dict
env_vars = {}
inputs = {}

var_inputs_global = {
    'bash_continue': True,
    'snakemake': True,
    'bashdownstream': False,
    'verbose': False,
    'snakemake_dry_run': False,
    'snakemake_dag': False,
    'export-figs': False,
    'condition_name': "condition",
    'name': 'GUAP_Unnamed_run',
    'skip_QC': False,
    'skip_trimmomatic': False,
    'trim_min_length': 50,
    'remove_primers': False,
    'min_length': 50,
    'trunc-f' :0,
    'trunc-r':0,
    'trim-l':0,
    'trim-r':0,
    'maxee-f':4,
    'maxee-r':5,
    'min-overlap':10,
    'chimera-method':"consensus",
    'deblur': False,
    'deblur_trim_length': 100,
    "use_QIIME2": False,
    "choose_classifier": "qiime",
    "train": False
}

# stores system std.err/out
old_stderr = sys.stderr
old_stdout = sys.stdout    
