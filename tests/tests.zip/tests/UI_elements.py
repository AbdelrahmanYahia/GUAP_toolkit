# import packages 
from guizero import *
from tkinter import filedialog
from tkinter import *
import customtkinter
import sys
from datetime import datetime
from UI.UI_vars import *
from UI.Analysis_16s import _16s_analysis
from UI.UI_classes import *
from UI import UI_app 
def button_command_obj(txt):
    print(txt)
    print("obj executed")

class Log_frame(customtkinter.CTkTextbox):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        # self.log_frame = customtkinter.CTkTextbox(parent,corner_radius=5)
        self.insert("insert", system_info + "\n")
        self.configure(state="disabled")  # configure textbox to be read-only

    def grid(self, sticky=("nswe"), **kwargs):
        super().grid(sticky=sticky, **kwargs)

    def update_log(self,txt):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.configure(state="normal")  # configure textbox to be read-only
        self.insert("end", current_time + "     " + str(txt) + "\n")
        self.configure(state="disabled")  # configure textbox to be read-only
        self.yview(END)

class Side_frame(customtkinter.CTkFrame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)

        #================ configure side frame ===============

        self.rowconfigure((0, 1, 2, 3), weight=1)
        self.label_1 = customtkinter.CTkLabel(self,
                                        text="GUAP toolkit",
                                        text_font=("Roboto Medium", -16)) 
        self.label_1.grid(row=0, column=0,padx=5,pady=5)

        self.button_16s = customtkinter.CTkButton(self,
                                                text="16s rRNA", fg_color=("gray75", "gray30"),  # <- custom tuple-color
                                                command=lambda: self.button_command("16s", 
                                                parent.set_options_frame( 
                                                _16s_analysis(parent,corner_radius=5))))
        self.button_16s.grid(row=1, column=0,padx=5,pady=5,sticky="ns")


        self.button_RNA = customtkinter.CTkButton(self,
                                                text="RNAseq", fg_color=("gray75", "gray30"), 
                                                command=lambda: self.button_command("RNA", 
                                                button_command_obj("test")))
        self.button_RNA.grid(row=2, column=0,padx=5,pady=5,sticky="ns")


        self.button_WES = customtkinter.CTkButton(self,
                                                text="WES", fg_color=("gray75", "gray30"), 
                                                command=lambda: self.button_command("WES", 
                                                button_command_obj("test")))
        self.button_WES.grid(row=3, column=0,padx=5,pady=5,sticky="ns")


        self.button_WGS = customtkinter.CTkButton(self,
                                                text="WGS", fg_color=("gray75", "gray30"), 
                                                command=lambda: self.button_command("WGS", 
                                                button_command_obj("test")))
        self.button_WGS.grid(row=4, column=0,padx=5,pady=5,sticky="ns")

        self.change_theme_switch = customtkinter.CTkSwitch(self,
                                                text="Dark Mode",
                                                command=parent.change_mode)

        self.change_theme_switch.grid(row= 8, pady=10, padx=10, sticky="s",rowspan=4)



    def grid(self, sticky=("nswe"), **kwargs):
        super().grid(sticky=sticky, **kwargs)

    def button_command(self, button, obj):
        if button in ["WES", "RNA", "16s", "WGS"]:
            UI_app.log_frame.update_log(f"{button} started")
            UI_app.statusbar.update(f"{button} started")
            
        else:
            print(f"ERROR: {button} is not defined!")
        return obj

class config_frame(customtkinter.CTkFrame):

    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)

        #============== configure options frame ===============

        # self.side_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)
        # self.side_frame.columnconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)

        var_inputs_global['threads'] = all_threads
        var_inputs_global['input'] = StringVar()
        var_inputs_global['output'] = StringVar()
        var_inputs_global['metadata'] = StringVar()


        self.threads_str = StringVar()
        self.threads_str.set(f"Threads = {all_threads}")

        # redirct the analysis to log frame switch
        env_vars["redswitch"] = customtkinter.CTkSwitch(self,
                                                text="stout/err redirect",
                                                command=self.redirect_out)
        env_vars["redswitch"].grid(row= 0, column=2, pady=10, padx=10, sticky="s")


        # frame label
        self.label_2 = customtkinter.CTkLabel(self,
                                        text="Basic configuration",
                                        text_font=("Roboto Medium", -16)) 
        self.label_2.grid(row=0, column=0,padx=5,pady=5)
        # get input dir
        self.input_btn = customtkinter.CTkButton(self,
                                                text="In Dir",
                                                command= lambda:
                                                var_inputs_global['input'].set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )

        self.input_btn.grid(row=1, column=0,sticky="nswe", pady=5, padx=5)

        self.input_label = customtkinter.CTkLabel(self,
                                                  textvariable=var_inputs_global['input'])

        self.input_label.grid(row=1, column=1, sticky="w", columnspan=2)


        # get output dir
        self.output_btn = customtkinter.CTkButton(self,
                                                text="Out Dir",
                                                command= lambda:
                                                var_inputs_global['output'].set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )

        self.output_btn.grid(row=2, column=0,sticky="nswe", pady=5, padx=5)
        self.output_label = customtkinter.CTkLabel(self,
                                                  textvariable=var_inputs_global['output'])
        self.output_label.grid(row=2, column=1,sticky="w", columnspan=2, pady=5)


        # get metadata file 
        env_vars["metadata_btn"] = customtkinter.CTkButton(self,
                                                text="metadata",
                                                command= lambda:
                                                var_inputs_global['metadata'].set(filedialog.askopenfilename(initialdir= "~/", title='Please select a directory')))
        env_vars["metadata_btn"].grid(row=3, column=0,sticky="nswe", pady=5, padx=5)
        env_vars["metadata_btn"].configure(state="disabled", text="choose analysis to enable")

        self.metadata_LABEL = customtkinter.CTkLabel(self,
                                                  textvariable=var_inputs_global['metadata'])
        self.metadata_LABEL.grid(row=3, column=1,sticky="w", columnspan=2, pady=5)


        # set number of threads
        self.N_threads = customtkinter.CTkSlider(self,from_=4, to=all_threads,number_of_steps=4-all_threads,
                                                command=self.get_N_threads)
        self.N_threads.grid(row=4, column=1, columnspan=2, pady=5, padx=5, sticky="")
        self.N_threads.set(all_threads)
        self.threads_label = customtkinter.CTkLabel(self,
                                                textvariable=self.threads_str)              
        self.threads_label.grid(row=4, column=0, columnspan=1, pady=5, padx=5)

        # set options 
        self.set_snakemake = customtkinter.CTkSwitch(self, 
                                                command= lambda:var_inputs_global['snakemake'] == True if self.set_snakemake.get() == 1 else var_inputs_global['snakemake'] == False ,
                                                text="Use Snakemake",)
        self.set_snakemake.grid(row= 5,column=0,columnspan=1, pady=5, padx=5, sticky="w")
        self.set_snakemake.toggle()

        self.smk_dry_run = customtkinter.CTkSwitch(self,
                                                command= lambda:var_inputs_global['snakemake_dry_run'] == True if self.smk_dry_run.get() == 1 else var_inputs_global['snakemake'] == False ,
                                                text="Snakemake Dry Run",)
        self.smk_dry_run.grid(row= 5,column=1,columnspan=1, pady=5, padx=5, sticky="w")

        self.bash_continue = customtkinter.CTkSwitch(self,
                                                command= lambda:var_inputs_global['bash_continue'] == True if self.bash_continue.get() == 1 else var_inputs_global['snakemake'] == False ,
                                                text="Continue")
        self.bash_continue.toggle()
        self.bash_continue.grid(row= 5,column=2,columnspan=1, pady=5, padx=5, sticky="w")


    def grid(self, sticky=("nswe"), **kwargs):
        super().grid(sticky=sticky, **kwargs)


    def get_N_threads(self,value):
        self.threads_str.set(f"Threads = {int(value)}")
        var_inputs_global['threads'] = value
        status_bar.update(self ="", txt=f"Number of Threads was set to {int(value)}")

    def button_command(self, button, obj):
        if button in ["WES", "RNA", "16s", "WGS"]:
            print(f"{button} pressed.")
            UI_app.GUAP_GUI.log_frame.update_log(f"{button} started")
            UI_app.GUAP_GUI.statusbar.update(f"{button} started")
            
        else:
            print(f"ERROR: {button} is not defined!")
        return obj

    def redirect_out(self):
        if env_vars["redswitch"].get() == 1:
            sys.stdout = TextRedirector(UI_app.log_frame, "stdout")
            sys.stderr = TextRedirector(UI_app.log_frame, "stderr")
            status_bar.update(self ="", txt="stdout and stderr will be redirected to log screen")

        else:
            sys.stdout = old_stdout
            sys.stderr = old_stderr 
            status_bar.update(self ="", txt="stdout and stderr will be redirected to terminal")

class status_bar(customtkinter.CTkFrame):
    status_strvar = ""
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        status_bar.status_strvar = StringVar()
        status_bar.status_strvar.set("GUAP toolkit initiated")
        self.status_var = customtkinter.CTkLabel(self, text_color= "Grey",
                            textvariable=self.status_strvar,
                            relief=SUNKEN)
        self.status_var.grid(row=0, column=0, padx=1, pady=1)

    def update(self, txt):
        status_bar.status_strvar.set(txt)

