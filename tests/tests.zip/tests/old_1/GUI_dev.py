#!/usr/bin/python3

# import packages 
from guizero import *
import multiprocessing
import tkinter
from tkinter import filedialog
from tkinter import *
import tkinter.messagebox
import customtkinter
import sys
import logging
import psutil
import os
from datetime import datetime
from datetime import date
import platform


# set theme in Customtkinter
customtkinter.set_appearance_mode("Light")  # Modes: "System" (standard), "Dark", "Light"
customtkinter.set_default_color_theme("/home/abdelrahman/Desktop/GUAP_GUI/bin/custom_theme.json")

all_threads = multiprocessing.cpu_count()
platform_ = str(platform.system())

use_QIIME2 = False
deblur = False


if all_threads < 4:
    logging.error(f"\033[;31;1mYour System doesn't have enough threads to run the analyis")
    exit(1)
all_mem =int( (psutil.virtual_memory().total ) / 1000000000 )
if all_mem < 7:
    logging.error(f"\033[;31;1mYour System doesn't have enough memory to run the analyis")
    exit(1)

today = date.today()
d1 = today.strftime("%d-%b-%Y")
now = datetime.now()
current_time = now.strftime("%H:%M:%S")

system_info = f"""{d1}    GUAP GUI started at   {current_time}

System platform:   {platform_}
total threads:      {all_threads}
total memory:     {all_mem}

"""
def Run_analysis(analysis_type):
    print(f"""{analysis_type} analysis will start""")

old_stderr = sys.stderr
old_stdout = sys.stdout    

# create app class to better organize 
class App(customtkinter.CTk):
    WIDTH = 1200
    HEIGHT = 700
    

    def __init__(self):
        super().__init__()

        self.title("GUAP")
        self.geometry(f"{App.WIDTH}x{App.HEIGHT}")
        self.protocol("WM_DELETE_WINDOW", self.on_closing) # call .on_closing() when app gets closed
        # create side frame 
        self.side_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.side_frame.grid(row=0, column=0, columnspan=2, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create config_frame
        self.config_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.config_frame.grid(row=0, column=2, columnspan=6, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create options_frame
        self.options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nsew",padx=5, pady=5)

        # create Statusbar frame
        self.statusbar_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.statusbar_frame.grid(row=11, column=0, columnspan=20, rowspan=1, sticky= W+E,padx=5, pady=5)

        # create log_frame

        self.log_frame = customtkinter.CTkTextbox(master=self,corner_radius=5)
        self.log_frame.grid(row=0, column=10, columnspan=8, rowspan=11, sticky="nswe",padx=5, pady=5)
        self.log_frame.insert("insert", system_info + "\n")

        self.log_frame.configure(state="disabled")  # configure textbox to be read-only
        
        # grid configure
        self.grid_columnconfigure(15,weight=1)
        self.grid_rowconfigure(8,weight=1)

        #================ configure status bar ===============

        self.status_bar = StringVar()
        self.status_bar.set("GUAP toolkit")
        self.status_var = customtkinter.CTkLabel(master=self.statusbar_frame, text_color= "Grey",
                            textvariable=self.status_bar,
                            relief=SUNKEN)
        self.status_var.grid(row=0, column=0, padx=1, pady=1)


        #================ configure side frame ===============

        self.side_frame.rowconfigure((0, 1, 2, 3), weight=1)
        self.label_1 = customtkinter.CTkLabel(master=self.side_frame,
                                        text="GUAP toolkit",
                                        text_font=("Roboto Medium", -16)) 
        self.label_1.grid(row=0, column=0,padx=5,pady=5)

        self.button_16s = customtkinter.CTkButton(master=self.side_frame,
                                                text="16s rRNA", fg_color=("gray75", "gray30"),  # <- custom tuple-color
                                                command=self.bt_16s_event)
        self.button_16s.grid(row=1, column=0,padx=5,pady=5,sticky="ns")


        self.button_RNA = customtkinter.CTkButton(master=self.side_frame,
                                                text="RNAseq", fg_color=("gray75", "gray30"), command=self.bt_RNA_event)
        self.button_RNA.grid(row=2, column=0,padx=5,pady=5,sticky="ns")


        self.button_WES = customtkinter.CTkButton(master=self.side_frame,
                                                text="WES", fg_color=("gray75", "gray30"), command=self.bt_WES_event)
        self.button_WES.grid(row=3, column=0,padx=5,pady=5,sticky="ns")


        self.button_WGS = customtkinter.CTkButton(master=self.side_frame,
                                                text="WGS", fg_color=("gray75", "gray30"), command=self.bt_WGS_event)
        self.button_WGS.grid(row=4, column=0,padx=5,pady=5,sticky="ns")

        self.change_theme_switch = customtkinter.CTkSwitch(master=self.side_frame,
                                                text="Dark Mode",
                                                command=self.change_mode)

        self.change_theme_switch.grid(row= 8, pady=10, padx=10, sticky="s",rowspan=4)

        #============== configure options frame ===============

        # self.side_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)
        # self.side_frame.columnconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)

        self.nthreads = StringVar()
        self.indir = StringVar()
        self.outdir = StringVar()
        self.metdata = StringVar()
        
        # dir choose
        self.redswitch = customtkinter.CTkSwitch(master=self.config_frame,
                                                text="stout/err redirect",
                                                command=self.redirect_out)

        self.redswitch.grid(row= 0, column=2, pady=10, padx=10, sticky="s")
        self.label_2 = customtkinter.CTkLabel(master=self.config_frame,
                                        text="Basic configuration",
                                        text_font=("Roboto Medium", -16)) 
        self.label_2.grid(row=0, column=0,padx=5,pady=5)
        self.input_btn = customtkinter.CTkButton(master=self.config_frame,
                                                text="In Dir",
                                                command= lambda:
                                                self.indir.set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )
        self.input_btn.grid(row=1, column=0,sticky="nswe", pady=5, padx=5)

        self.input_label = customtkinter.CTkLabel(master=self.config_frame,
                                                  textvariable=self.indir)
        self.input_label.grid(row=1, column=1, sticky="w", columnspan=2)

        self.output_btn = customtkinter.CTkButton(master=self.config_frame,
                                                text="Out Dir",
                                                command= lambda:
                                                self.outdir.set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )

        self.output_btn.grid(row=2, column=0,sticky="nswe", pady=5, padx=5)
        self.output_label = customtkinter.CTkLabel(master=self.config_frame,
                                                  textvariable=self.outdir)
        self.output_label.grid(row=2, column=1,sticky="w", columnspan=2, pady=5)

        self.metadata_btn = customtkinter.CTkButton(master=self.config_frame,
                                                text="metadata",
                                                command= lambda:
                                                self.metdata.set(filedialog.askopenfilename(initialdir= "~/", title='Please select a directory')))
        self.metadata_btn.grid(row=3, column=0,sticky="nswe", pady=5, padx=5)
        self.metadata_btn.configure(state="disabled", text="choose analysis to enable")

        self.metadata_LABEL = customtkinter.CTkLabel(master=self.config_frame,
                                                  textvariable=self.metdata)
        self.metadata_LABEL.grid(row=3, column=1,sticky="w", columnspan=2, pady=5)

        self.N_threads = customtkinter.CTkSlider(master=self.config_frame,from_=4, to=all_threads,number_of_steps=4-all_threads,
                                                command=self.get_N_threads)
        self.N_threads.grid(row=4, column=1, columnspan=2, pady=5, padx=5, sticky="")
        self.N_threads.set(all_threads)
        self.nthreads.set(f"Threads = {int(self.N_threads.get())}")

        self.threads_label = customtkinter.CTkLabel(master=self.config_frame,
                                                textvariable=self.nthreads)
                                                
        self.threads_label.grid(row=4, column=0, columnspan=1, pady=5, padx=5)

        self.set_snakemake = customtkinter.CTkSwitch(master=self.config_frame, command= self.set_snakemake_,
                                                text="Use Snakemake",)
        self.set_snakemake.grid(row= 5,column=0,columnspan=1, pady=5, padx=5, sticky="w")
        self.set_snakemake.toggle()

        self.smk_dry_run = customtkinter.CTkSwitch(master=self.config_frame,command= self.set_snakemake_dryrun,
                                                text="Snakemake Dry Run",)
        self.smk_dry_run.grid(row= 5,column=1,columnspan=1, pady=5, padx=5, sticky="w")

        self.bash_continue = customtkinter.CTkSwitch(master=self.config_frame,command= self.set_bash_continue,
                                                text="Continue")
        self.bash_continue.toggle()
        self.bash_continue.grid(row= 5,column=2,columnspan=1, pady=5, padx=5, sticky="w")

class file_input_frame(customtkinter.CTkFrame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)



    def update_log(self,txt):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.log_frame.configure(state="normal")  # configure textbox to be read-only
        self.log_frame.insert("end", current_time + "     " + str(txt) + "\n")
        self.log_frame.configure(state="disabled")  # configure textbox to be read-only
        self.log_frame.yview(END)
        
    def set_bash_continue(self):
        if self.bash_continue.get() == 1:
            bashcontinue=True
            self.update_log("Analysis will continue on restart")
        else:
            bashcontinue=False
            self.update_log("Analysis will overwrite on restart")

    def set_snakemake_dryrun(self):
        if self.smk_dry_run.get() == 1:
            smk_dryrun=True
            self.update_log("Snakemake Dry run is set")
        else:
            smk_dryrun=False
            self.update_log("Snakemake full run is set")

    def set_snakemake_(self):
        if self.set_snakemake.get() == 1:
            usesnakemake=True
            self.update_log("Snakemake engine will be used")
        else:
            usesnakemake=False
            self.update_log("Bash engine will be used")

    def change_mode(self):
        if self.change_theme_switch.get() == 1:
            customtkinter.set_appearance_mode("dark")
            self.update_log("Mode changed to dark")
        else:
            customtkinter.set_appearance_mode("light")
            self.update_log("Mode changed to light")

    def on_closing(self, event=0):
        self.destroy()

    def start(self):
        self.mainloop()

    def bt_16s_event(self):
        self.redswitch.select()
        self.redirect_out()
        self.metadata_btn.configure(state="normal", text="Metadata") # "normal" (standard) or "disabled" 

        # classifier 
        def optionmenu_callback(choice):
            print("optionmenu dropdown clicked:", choice)
        self.classifier_file = StringVar()

        # create options_frame
        self.options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nswe",padx=5, pady=5)
        self.options_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21), weight=1)
        self.options_frame.columnconfigure((0,1,2,3), weight=1)
        self.status_bar.set("16s started")
        self.update_log("""16s analysis
In advanced options you can set:
    1. Dada2 params
    2. deblur min len
    3. trimmomatic min len
    4. naive-bayes classifier params
    5. Remove primers
    6. downstream max-depth
    7. downstream sampling depth

for more info visit:
    URL://@url@info.wiki
""")

        # labels
        self.label_QC = customtkinter.CTkLabel(master=self.options_frame, text="QC",
                                        text_font=("Roboto Medium", -16))
        self.label_QC.grid(row=0, column=0,padx=5,pady=5,sticky="w")

        self.label_ASV = customtkinter.CTkLabel(master=self.options_frame, text="ASV",
                                        text_font=("Roboto Medium", -16))
        self.label_ASV.grid(row=3, column=0,padx=5,pady=5,sticky="w")

        self.label_class = customtkinter.CTkLabel(master=self.options_frame, text="Classifier",
                                        text_font=("Roboto Medium", -16))
        self.label_class.grid(row=0, column=1,padx=5,pady=5)

        self.label_figs = customtkinter.CTkLabel(master=self.options_frame, text="Export Figs",
                                        text_font=("Roboto Medium", -16))
        self.label_figs.grid(row=3, column=1,padx=5,pady=5)

        # QC options
        self.skip_QC = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.skip_QC.get() == 1 else use_QIIME2 == False, text="Skip QC")
        self.skip_QC.grid(row= 1,column=0, pady=5, padx=10,sticky="w")
        
        self.skip_trim = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.skip_trim.get() == 1 else use_QIIME2 == False, text="Skip trimming")
        self.skip_trim.grid(row= 2,column=0, pady=5, padx=10,sticky="w")
        self.skip_trim.toggle()

        # classifier btn
        self.classifier_btn_label = customtkinter.CTkLabel(master=self.options_frame,text="Choose Classifier")
        self.classifier_btn_label.grid(row= 1,column=1, pady=5, padx=0,sticky="w")

        self.classifier_btn = customtkinter.CTkOptionMenu(master=self.options_frame,values=["dada2", "QIIME2 naive-bayes"],command=optionmenu_callback)
        self.classifier_btn.grid(row= 1,column=2, pady=5, padx=0,sticky="w")
        self.classifier_btn.set("QIIME2 naive-bayes")  # set initial value
        self.classifier_file_btn = customtkinter.CTkButton(master=self.options_frame,text="classifier file",command= lambda:self.classifier_file.set(filedialog.askopenfilename(initialdir= "~/", title='Please select a directory')))
        self.classifier_file_btn.grid(row=2, column=1, pady=5, padx=5,sticky="w")
        self.classifier_file_LABEL = customtkinter.CTkLabel(master=self.options_frame,textvariable=self.classifier_file)
        self.classifier_file_LABEL.grid(row=2, column=2,sticky="w", pady=5)

        # ASV options
        self.use_qiime2 = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.use_qiime2.get() == 1 else use_QIIME2 == False, text="Use QIIME2")
        self.use_qiime2.grid(row= 4,column=0, pady=5, padx=10,sticky="w")
        
        self.use_deblur = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.use_deblur.get() == 1 else use_QIIME2 == False, text="Use DEBLUR")
        self.use_deblur.grid(row= 5,column=0, pady=5, padx=10,sticky="w")

        self.adv_options_btn = customtkinter.CTkButton(master=self.options_frame, 
                                                        fg_color=["gray85", "gray15"],   # <- no fg_color
        text="Advanced Options",
command= self.create_adv_16s )
        self.adv_options_btn.grid(row=21, column=0, padx=15, pady=15,sticky=W+S)

        # export figs 
        self.export_figs_btn = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.export_figs_btn.get() == 1 else use_QIIME2 == False, text="Export figs")
        self.export_figs_btn.grid(row= 4,column=1, pady=5, padx=10,sticky="w")
        
        self.downstream_btn = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.downstream_btn.get() == 1 else use_QIIME2 == False, text="QIIME2 Downstream")
        self.downstream_btn.grid(row= 5,column=1, pady=5, padx=10,sticky="w")
        # run btn
        self.Run_btn_16s= customtkinter.CTkButton(master=self.options_frame, command=lambda: Run_analysis("16s"), text="RUN")
        self.Run_btn_16s.grid(row=21,column=3, sticky=E+S, padx=15, pady=15)


    def create_adv_16s(self):
        advanced_options_16s = customtkinter.CTkToplevel(self)
        advanced_options_16s.geometry("600x400")
        advanced_options_16s.title("16s Advanced Options")
        advanced_options_16s.grid_columnconfigure(0,weight=1)
        advanced_options_16s.grid_rowconfigure(0,weight=1)

        advanced_options_16s.Main_frame = customtkinter.CTkFrame(master=advanced_options_16s,corner_radius=5)
        advanced_options_16s.Main_frame.grid(row=0, column=0, sticky="nswe",padx=5, pady=5)
        advanced_options_16s.Main_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13), weight=1)
        advanced_options_16s.Main_frame.columnconfigure((0, 1), weight=1)

        advanced_options_16s.dada_tff_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tff_ent.grid(row=2, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tfr_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tfr_ent.grid(row=3, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tmf_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tmf_ent.grid(row=4, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tmr_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tmr_ent.grid(row=5, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_eff_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="4")
        advanced_options_16s.dada_eff_ent.grid(row=6, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_efr_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="5")
        advanced_options_16s.dada_efr_ent.grid(row=7, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trunclength Forward",)
        advanced_options_16s.dada_tff_label.grid(row=2, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trunclength Reverse")
        advanced_options_16s.dada_tff_label.grid(row=3, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trim length Forward")
        advanced_options_16s.dada_tff_label.grid(row=4, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trim length Reverse")
        advanced_options_16s.dada_tff_label.grid(row=5, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="MaxEE Reverse")
        advanced_options_16s.dada_tff_label.grid(row=6, column=0, padx=5, pady=5,sticky="w",columnspan=2) 

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="MaxEE Reverse")
        advanced_options_16s.dada_tff_label.grid(row=7, column=0, padx=5, pady=5,sticky="w",columnspan=2) 
        

    def bt_RNA_event(self):
                # create options_frame
        self.options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nswe",padx=5, pady=5)
        self.status_bar.set("RNA started")
        self.update_log("RNA analysis")

        # self.options_frame = customtkinter.CTkFrame(master=self)
        # self.options_frame.grid(row=0, column=1, sticky="nswe", padx=10, pady=5)
        # ============ options_frame ============

        # # configure grid layout (3x7)
        # self.options_frame.rowconfigure((0, 1, 2, 3), weight=1)
        # self.options_frame.rowconfigure(7, weight=10)
        # self.options_frame.columnconfigure((0, 1), weight=1)
        # self.options_frame.columnconfigure(2, weight=0)

        self.frame_info = customtkinter.CTkFrame(master=self.options_frame)
        self.frame_info.grid(row=0, column=0, columnspan=2, rowspan=4, pady=20, padx=20, sticky="nsew")

        # ============ frame_info ============

        # configure grid layout (1x1)
        self.frame_info.rowconfigure(0, weight=1)
        self.frame_info.columnconfigure(0, weight=1)

        self.label_info_1 = customtkinter.CTkLabel(master=self.frame_info,
                                                   text="CTkLabel: this is an app for ,\n" +
                                                        "the amazing Abdelrahman Ehab,\n" +
                                                        "from abzoo",
                                                   height=100,
                                                   fg_color=("white", "gray38"),    justify=tkinter.LEFT)
        self.label_info_1.grid(column=0, row=0, sticky="nwe", padx=15, pady=15)

        self.progressbar = customtkinter.CTkProgressBar(master=self.frame_info)
        self.progressbar.grid(row=1, column=0, sticky="ew", padx=15, pady=15)

        # ============ options_frame ============

        self.radio_var = tkinter.IntVar(value=0)
        self.label_radio_group = customtkinter.CTkLabel(master=self.options_frame,
                                                        text="CTkRadioButton Group:")
        self.label_radio_group.grid(row=0, column=2, columnspan=1, pady=5, padx=5, sticky="")

        self.radio_button_1 = customtkinter.CTkRadioButton(master=self.options_frame,
                                                           variable=self.radio_var,
                                                           value=0)
        self.radio_button_1.grid(row=1, column=2, pady=5, padx=5, sticky="n")

        self.radio_button_2 = customtkinter.CTkRadioButton(master=self.options_frame,
                                                           variable=self.radio_var,
                                                           value=1)
        self.radio_button_2.grid(row=2, column=2, pady=5, padx=5, sticky="n")

        self.radio_button_3 = customtkinter.CTkRadioButton(master=self.options_frame,
                                                           variable=self.radio_var,
                                                           value=2)
        self.radio_button_3.grid(row=3, column=2, pady=5, padx=5, sticky="n")

        self.slider_1 = customtkinter.CTkSlider(master=self.options_frame, from_=0,
                                                to=1,
                                                number_of_steps=3,
                                                command=self.progressbar.set)
        self.slider_1.grid(row=4, column=0, columnspan=2, pady=10, padx=20, sticky="we")

        self.slider_2 = customtkinter.CTkSlider(master=self.options_frame,
                                                command=self.progressbar.set)
        self.slider_2.grid(row=5, column=0, columnspan=2, pady=10, padx=20, sticky="we")

        self.slider_button_1 = customtkinter.CTkButton(master=self.options_frame,
                                                       height=25,
                                                       text="CTkButton s1",
                                                       command=self.button_event)
        self.slider_button_1.grid(row=4, column=2, columnspan=1, pady=10, padx=20, sticky="we")

        self.slider_button_2 = customtkinter.CTkButton(master=self.options_frame,
                                                       height=25,
                                                       text="CTkButton s2",
                                                       command=self.button_event)
        self.slider_button_2.grid(row=5, column=2, columnspan=1, pady=10, padx=20, sticky="we")

        self.checkbox_button_1 = customtkinter.CTkButton(master=self.options_frame,
                                                         height=25,
                                                         text="CTkButton c1",
                                                         border_width=3,   # <- custom border_width
                                                         fg_color=None,   # <- no fg_color
                                                         command=self.button_event)
        self.checkbox_button_1.grid(row=6, column=2, columnspan=1, pady=10, padx=20, sticky="we")

        self.check_box_1 = customtkinter.CTkCheckBox(master=self.options_frame,
                                                     text="CTkCheckBox1")
        self.check_box_1.grid(row=6, column=0, pady=10, padx=20, sticky="w")

        self.check_box_2 = customtkinter.CTkCheckBox(master=self.options_frame,
                                                     text="CTkCheckBox2")
        self.check_box_2.grid(row=6, column=1, pady=10, padx=20, sticky="w")

        self.entry = customtkinter.CTkEntry(master=self.options_frame,
                                            
                                            placeholder_text="CTkEntry")
        self.entry.grid(row=8, column=0, columnspan=2, pady=20, padx=20, sticky="we")

        self.button_5 = customtkinter.CTkButton(master=self.options_frame,
                                                text="CTkButton",
                                                command=self.button_event)
        self.button_5.grid(row=8, column=2, columnspan=1, pady=20, padx=20, sticky="we")

        # set default values
        self.radio_button_1.select()
        self.slider_1.set(0.2)
        self.slider_2.set(0.7)
        self.progressbar.set(0.5)
        self.slider_button_1.configure(state=tkinter.DISABLED, text="Disabled Button")
        self.radio_button_3.configure(state=tkinter.DISABLED)
        self.check_box_1.configure(state=tkinter.DISABLED, text="CheckBox disabled")
        self.check_box_2.select()

    
    def get_N_threads(self,value):
        self.nthreads.set(f"Threads = {int(value)}")
        self.status_bar.set(f"Number of Threads was set to {int(value)}")

    def bt_WES_event(self):
                # create options_frame
        self.options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nswe",padx=5, pady=5)
        self.status_bar.set("WES started")
        self.update_log("WES analysis")

    def bt_WGS_event(self):
                # create options_frame
        self.options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nswe",padx=5, pady=5)
        self.status_bar.set("WGS started")
        self.update_log("WGS analysis")

    def button_event(self):
        print(f"{self} Button pressed")

    def chooseDir(self):
        print("choose dir is not working :D")

class TextRedirector(object):
    def __init__(self, widget, tag="stdout"):
        super().__init__()
        self.widget = widget
        self.tag = tag
    def write(self, strg):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.widget.configure(state="normal")
        self.widget.insert("end", current_time +"        " + strg + "\n")
        self.widget.configure(state="disabled")
        self.widget.yview(END)

if __name__ == "__main__":
    app = App()
    app.start()