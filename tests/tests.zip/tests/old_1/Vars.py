import logging
import psutil
import platform
import multiprocessing
from datetime import date
from datetime import datetime
import sys

global inputs_global
global class_vars
inputs_global = {}
class_vars = {}

all_threads = multiprocessing.cpu_count()
platform_ = str(platform.system())


# check env specs
if all_threads < 4:
    logging.error(f"\033[;31;1mYour System doesn't have enough threads to run the analyis")
    exit(1)
all_mem =int( (psutil.virtual_memory().total ) / 1000000000 )
if all_mem < 7:
    logging.error(f"\033[;31;1mYour System doesn't have enough memory to run the analyis")
    exit(1)

# set env vars
today = date.today()
current_date = today.strftime("%d-%b-%Y")
now = datetime.now()
current_time = now.strftime("%H:%M:%S")

system_info = f"""{current_date}    GUAP GUI started at   {current_time}

System platform:   {platform_}
total threads:      {all_threads}
total memory:     {all_mem}

"""

# save defualt print to terminal 
old_stderr = sys.stderr
old_stdout = sys.stdout 