import customtkinter
import os
import sys

My_DIR = (os.path.abspath(__file__)).replace("GUI.py","")
sys.path.append(f"{My_DIR}")
import Vars

Vars.inputs_global = {
    'bash_continue': True,
    'snakemake': True,
    'bashdownstream': False,
    'verbose': False,
    'snakemake_dry_run': False,
    'snakemake_dag': False,
    'export-figs': False,
    'condition_name': "condition",
    'name': 'GUAP_Unnamed_run',
    'skip_QC': False,
    'skip_trimmomatic': False,
    'trim_min_length': 50,
    'remove_primers': False,
    'min_length': 50,
    'trunc-f' :0,
    'trunc-r':0,
    'trim-l':0,
    'trim-r':0,
    'maxee-f':4,
    'maxee-r':5,
    'min-overlap':10,
    'chimera-method':"consensus",
    'deblur': False,
    'deblur_trim_length': 100,
    "use_QIIME2": False,
    "choose_classifier": "qiime",
    "train": False
}

class analysis_16s(customtkinter.CTk):
    def __init__(self,parent,**kwargs):
        super().__init__(self,parent, **kwargs)

    
    def bt_16s_event(self,parent):
        parent.redswitch.select()
        self.redirect_out()
        self.metadata_btn.configure(state="normal", text="Metadata") # "normal" (standard) or "disabled" 

        # classifier 
        def optionmenu_callback(choice):
            print("optionmenu dropdown clicked:", choice)
        self.classifier_file = StringVar()

        # create options_frame
        self.options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nswe",padx=5, pady=5)
        self.options_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21), weight=1)
        self.options_frame.columnconfigure((0,1,2,3), weight=1)
        self.status_bar.set("16s started")
        self.update_log("""16s analysis
In advanced options you can set:
    1. Dada2 params
    2. deblur min len
    3. trimmomatic min len
    4. naive-bayes classifier params
    5. Remove primers
    6. downstream max-depth
    7. downstream sampling depth

for more info visit:
    URL://@url@info.wiki
""")

        # labels
        self.label_QC = customtkinter.CTkLabel(master=self.options_frame, text="QC",
                                        text_font=("Roboto Medium", -16))
        self.label_QC.grid(row=0, column=0,padx=5,pady=5,sticky="w")

        self.label_ASV = customtkinter.CTkLabel(master=self.options_frame, text="ASV",
                                        text_font=("Roboto Medium", -16))
        self.label_ASV.grid(row=3, column=0,padx=5,pady=5,sticky="w")

        self.label_class = customtkinter.CTkLabel(master=self.options_frame, text="Classifier",
                                        text_font=("Roboto Medium", -16))
        self.label_class.grid(row=0, column=1,padx=5,pady=5)

        self.label_figs = customtkinter.CTkLabel(master=self.options_frame, text="Export Figs",
                                        text_font=("Roboto Medium", -16))
        self.label_figs.grid(row=3, column=1,padx=5,pady=5)

        # QC options
        self.skip_QC = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.skip_QC.get() == 1 else use_QIIME2 == False, text="Skip QC")
        self.skip_QC.grid(row= 1,column=0, pady=5, padx=10,sticky="w")
        
        self.skip_trim = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.skip_trim.get() == 1 else use_QIIME2 == False, text="Skip trimming")
        self.skip_trim.grid(row= 2,column=0, pady=5, padx=10,sticky="w")
        self.skip_trim.toggle()

        # classifier btn
        self.classifier_btn_label = customtkinter.CTkLabel(master=self.options_frame,text="Choose Classifier")
        self.classifier_btn_label.grid(row= 1,column=1, pady=5, padx=0,sticky="w")

        self.classifier_btn = customtkinter.CTkOptionMenu(master=self.options_frame,values=["dada2", "QIIME2 naive-bayes"],command=optionmenu_callback)
        self.classifier_btn.grid(row= 1,column=2, pady=5, padx=0,sticky="w")
        self.classifier_btn.set("QIIME2 naive-bayes")  # set initial value
        self.classifier_file_btn = customtkinter.CTkButton(master=self.options_frame,text="classifier file",command= lambda:self.classifier_file.set(filedialog.askopenfilename(initialdir= "~/", title='Please select a directory')))
        self.classifier_file_btn.grid(row=2, column=1, pady=5, padx=5,sticky="w")
        self.classifier_file_LABEL = customtkinter.CTkLabel(master=self.options_frame,textvariable=self.classifier_file)
        self.classifier_file_LABEL.grid(row=2, column=2,sticky="w", pady=5)

        # ASV options
        self.use_qiime2 = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.use_qiime2.get() == 1 else use_QIIME2 == False, text="Use QIIME2")
        self.use_qiime2.grid(row= 4,column=0, pady=5, padx=10,sticky="w")
        
        self.use_deblur = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.use_deblur.get() == 1 else use_QIIME2 == False, text="Use DEBLUR")
        self.use_deblur.grid(row= 5,column=0, pady=5, padx=10,sticky="w")

        self.adv_options_btn = customtkinter.CTkButton(master=self.options_frame, 
                                                        fg_color=["gray85", "gray15"],   # <- no fg_color
        text="Advanced Options",
command= self.create_adv_16s )
        self.adv_options_btn.grid(row=21, column=0, padx=15, pady=15,sticky=W+S)

        # export figs 
        self.export_figs_btn = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.export_figs_btn.get() == 1 else use_QIIME2 == False, text="Export figs")
        self.export_figs_btn.grid(row= 4,column=1, pady=5, padx=10,sticky="w")
        
        self.downstream_btn = customtkinter.CTkCheckBox(master=self.options_frame, 
command= lambda: use_QIIME2 == True if self.downstream_btn.get() == 1 else use_QIIME2 == False, text="QIIME2 Downstream")
        self.downstream_btn.grid(row= 5,column=1, pady=5, padx=10,sticky="w")
        # run btn
        self.Run_btn_16s= customtkinter.CTkButton(master=self.options_frame, command=lambda: Run_analysis("16s"), text="RUN")
        self.Run_btn_16s.grid(row=21,column=3, sticky=E+S, padx=15, pady=15)


    def create_adv_16s(self):
        advanced_options_16s = customtkinter.CTkToplevel(self)
        advanced_options_16s.geometry("600x400")
        advanced_options_16s.title("16s Advanced Options")
        advanced_options_16s.grid_columnconfigure(0,weight=1)
        advanced_options_16s.grid_rowconfigure(0,weight=1)

        advanced_options_16s.Main_frame = customtkinter.CTkFrame(master=advanced_options_16s,corner_radius=5)
        advanced_options_16s.Main_frame.grid(row=0, column=0, sticky="nswe",padx=5, pady=5)
        advanced_options_16s.Main_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13), weight=1)
        advanced_options_16s.Main_frame.columnconfigure((0, 1), weight=1)

        advanced_options_16s.dada_tff_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tff_ent.grid(row=2, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tfr_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tfr_ent.grid(row=3, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tmf_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tmf_ent.grid(row=4, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tmr_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tmr_ent.grid(row=5, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_eff_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="4")
        advanced_options_16s.dada_eff_ent.grid(row=6, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_efr_ent = customtkinter.CTkEntry(master=advanced_options_16s.Main_frame,  placeholder_text="5")
        advanced_options_16s.dada_efr_ent.grid(row=7, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trunclength Forward",)
        advanced_options_16s.dada_tff_label.grid(row=2, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trunclength Reverse")
        advanced_options_16s.dada_tff_label.grid(row=3, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trim length Forward")
        advanced_options_16s.dada_tff_label.grid(row=4, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="trim length Reverse")
        advanced_options_16s.dada_tff_label.grid(row=5, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="MaxEE Reverse")
        advanced_options_16s.dada_tff_label.grid(row=6, column=0, padx=5, pady=5,sticky="w",columnspan=2) 

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(master=advanced_options_16s.Main_frame, text="MaxEE Reverse")
        advanced_options_16s.dada_tff_label.grid(row=7, column=0, padx=5, pady=5,sticky="w",columnspan=2) 
        


