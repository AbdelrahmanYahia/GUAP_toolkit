#!/usr/bin/python3

# import packages 
from tkinter import filedialog
from datetime import datetime
import customtkinter
from tkinter import *
import sys
import os

My_DIR = (os.path.abspath(__file__)).replace("GUI.py","")
sys.path.append(f"{My_DIR}")

# import modules
import UI_elements
from Vars import *
from _16s import *
# set theme in Customtkinter
customtkinter.set_appearance_mode("Light")  # Modes: "System" (standard), "Dark", "Light"
# customtkinter.set_default_color_theme("/home/abdelrahman/Desktop/GUAP_GUI/bin/custom_theme.json")
   


class TextRedirector(object):
    def __init__(self, widget, tag="stdout"):
        super().__init__()
        self.widget = widget
        self.tag = tag
    def write(self, strg):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.widget.configure(state="normal")
        self.widget.insert("end", current_time +"        " + strg + "\n")
        self.widget.configure(state="disabled")
        self.widget.yview(END)


# create app class to better organize 
class GUAP_GUI(customtkinter.CTk):
    WIDTH = 1200
    HEIGHT = 700
    def __init__(self,*args, **kwargs):
        super().__init__(*args, **kwargs)

        self.title("GUAP")
        self.geometry(f"{GUAP_GUI.WIDTH}x{GUAP_GUI.HEIGHT}")
        self.protocol("WM_DELETE_WINDOW", self.on_closing) # call .on_closing() when app gets closed
        
        # create side frame 
        self.side_frame = UI_elements.analysis_frame(self,corner_radius=5)
        self.side_frame.grid(row=0, column=0, columnspan=2, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create config_frame
        self.config_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.config_frame.grid(row=0, column=2, columnspan=6, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create options_frame
        self.options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nsew",padx=5, pady=5)

        # create Statusbar frame
        self.statusbar_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        self.statusbar_frame.grid(row=11, column=0, columnspan=20, rowspan=1, sticky= W+E,padx=5, pady=5)

        # create log_frame
        self.log_frame = customtkinter.CTkTextbox(master=self,corner_radius=5)
        self.log_frame.grid(row=0, column=10, columnspan=8, rowspan=11, sticky="nswe",padx=5, pady=5)
        self.log_frame.insert("insert", system_info + "\n")
        self.log_frame.configure(state="disabled")  # configure textbox to be read-only

        # grid configure
        self.grid_columnconfigure(15,weight=1)
        self.grid_rowconfigure(8,weight=1)


        #================ configure status bar ===============

        self.status_bar = StringVar()
        self.status_bar.set("GUAP toolkit")
        self.status_var = customtkinter.CTkLabel(master=self.statusbar_frame, text_color= "Grey",
                            textvariable=self.status_bar,
                            relief=SUNKEN)
        self.status_var.grid(row=0, column=0, padx=1, pady=1)

        #============== configure options frame ===============

        # self.side_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)
        # self.side_frame.columnconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)

        self.nthreads = StringVar()
        self.indir = StringVar()
        self.outdir = StringVar()
        self.metdata = StringVar()
        
        inputs_global['nthreads'] = self.nthreads
        inputs_global['indir'] = self.indir
        inputs_global['outdir'] = self.outdir
        inputs_global['metadata'] = self.metdata

        # dir choose
        self.redswitch = customtkinter.CTkSwitch(master=self.config_frame,
                                                text="stout/err redirect",
                                                command=self.redirect_out)

        self.redswitch.grid(row= 0, column=2, pady=10, padx=10, sticky="s")
        self.label_2 = customtkinter.CTkLabel(master=self.config_frame,
                                        text="Basic configuration",
                                        text_font=("Roboto Medium", -16)) 
        self.label_2.grid(row=0, column=0,padx=5,pady=5)
        self.input_btn = customtkinter.CTkButton(master=self.config_frame,
                                                text="In Dir",
                                                command= lambda:
                                                self.indir.set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )
        self.input_btn.grid(row=1, column=0,sticky="nswe", pady=5, padx=5)

        self.input_label = customtkinter.CTkLabel(master=self.config_frame,
                                                  textvariable=self.indir)
        self.input_label.grid(row=1, column=1, sticky="w", columnspan=2)

        self.output_btn = customtkinter.CTkButton(master=self.config_frame,
                                                text="Out Dir",
                                                command= lambda:
                                                self.outdir.set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )

        self.output_btn.grid(row=2, column=0,sticky="nswe", pady=5, padx=5)
        self.output_label = customtkinter.CTkLabel(master=self.config_frame,
                                                  textvariable=self.outdir)
        self.output_label.grid(row=2, column=1,sticky="w", columnspan=2, pady=5)

        self.metadata_btn = customtkinter.CTkButton(master=self.config_frame,
                                                text="metadata",
                                                command= lambda:
                                                self.metdata.set(filedialog.askopenfilename(initialdir= "~/", title='Please select a directory')))
        self.metadata_btn.grid(row=3, column=0,sticky="nswe", pady=5, padx=5)
        self.metadata_btn.configure(state="disabled", text="choose analysis to enable")

        self.metadata_LABEL = customtkinter.CTkLabel(master=self.config_frame,
                                                  textvariable=self.metdata)
        self.metadata_LABEL.grid(row=3, column=1,sticky="w", columnspan=2, pady=5)

        self.N_threads = customtkinter.CTkSlider(master=self.config_frame,from_=4, to=all_threads,number_of_steps=4-all_threads,
                                                command=self.get_N_threads)
        self.N_threads.grid(row=4, column=1, columnspan=2, pady=5, padx=5, sticky="")
        self.N_threads.set(all_threads)
        inputs_global['nthreads'].set(f"Threads = {int(self.N_threads.get())}")

        self.threads_label = customtkinter.CTkLabel(master=self.config_frame,
                                                textvariable=inputs_global['nthreads'])
                                                
        self.threads_label.grid(row=4, column=0, columnspan=1, pady=5, padx=5)

        self.set_snakemake = customtkinter.CTkSwitch(master=self.config_frame, command= self.set_snakemake_,
                                                text="Use Snakemake",)
        self.set_snakemake.grid(row= 5,column=0,columnspan=1, pady=5, padx=5, sticky="w")
        self.set_snakemake.toggle()

        self.smk_dry_run = customtkinter.CTkSwitch(master=self.config_frame,command= self.set_snakemake_dryrun,
                                                text="Snakemake Dry Run",)
        self.smk_dry_run.grid(row= 5,column=1,columnspan=1, pady=5, padx=5, sticky="w")

        self.bash_continue = customtkinter.CTkSwitch(master=self.config_frame,command= self.set_bash_continue,
                                                text="Continue")
        self.bash_continue.toggle()
        self.bash_continue.grid(row= 5,column=2,columnspan=1, pady=5, padx=5, sticky="w")


    def redirect_out(self):
        if self.redswitch.get() == 1:
            sys.stdout = TextRedirector(self.log_frame, "stdout")
            sys.stderr = TextRedirector(self.log_frame, "stderr")
            self.status_bar.set("stdout and stderr will be redirected to log screen")

        else:
            sys.stdout = old_stdout
            sys.stderr = old_stderr 
            self.status_bar.set("stdout and stderr will be redirected to terminal")

    def update_log(self,txt):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.log_frame.configure(state="normal")  # configure textbox to be read-only
        self.log_frame.insert("end", current_time + "     " + str(txt) + "\n")
        self.log_frame.configure(state="disabled")  # configure textbox to be read-only
        self.log_frame.yview(END)
        
    def set_bash_continue(self):
        if self.bash_continue.get() == 1:
            self.update_log("Analysis will continue on restart")
        else:
            self.update_log("Analysis will overwrite on restart")

    def set_snakemake_dryrun(self):
        if self.smk_dry_run.get() == 1:
            self.update_log("Snakemake Dry run is set")
        else:
            self.update_log("Snakemake full run is set")

    def set_snakemake_(self):
        if self.set_snakemake.get() == 1:
            self.update_log("Snakemake engine will be used")
        else:
            self.update_log("Bash engine will be used")
        
    def get_N_threads(self,value):
        inputs_global['nthreads'].set(f"Threads = {int(value)}")
        self.status_bar.set(f"Number of Threads was set to {int(value)}")


    def chooseDir(self):
        print("choose dir is not working :D")

    def on_closing(self, event=0):
        self.destroy()

    def start(self):
        self.mainloop()

        
    def change_mode(self):
        if self.side_frame.change_theme_switch.get() == 1:
            customtkinter.set_appearance_mode("dark")
            self.update_log("Mode changed to dark")
        else:
            customtkinter.set_appearance_mode("light")
            self.update_log("Mode changed to light")
    


if __name__ == "__main__":
    app = GUAP_GUI()
    app.start()