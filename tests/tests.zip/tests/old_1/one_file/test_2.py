def sum_(n1, n2):
    n1 = int(n1)
    n2 = int(n2)

    n3 = n1 + n2
    n4 = n3 +1 
    return n4

int1 = input("please insert n1: ")
int2 = input("please insert n2: ")




new = sum_(int1, int2)

print(new + 1)
print(n3)
