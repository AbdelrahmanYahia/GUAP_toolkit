#!/usr/bin/python3

# import packages 
from guizero import *
import multiprocessing
import tkinter as tk
from tkinter import filedialog
from tkinter import *
import tkinter.messagebox
import customtkinter
import sys
import logging
import psutil
import os
from datetime import datetime
from datetime import date
import platform

use_QIIME2 = True
# set theme in Customtkinter
customtkinter.set_appearance_mode("Light")  # Modes: "System" (standard), "Dark", "Light"
# customtkinter.set_default_color_theme("/home/abdelrahman/Desktop/GUAP_GUI/bin/custom_theme.json")

all_threads = multiprocessing.cpu_count()
platform_ = str(platform.system())


if all_threads < 4:
    logging.error(f"\033[;31;1mYour System doesn't have enough threads to run the analyis")
    exit(1)
all_mem =int( (psutil.virtual_memory().total ) / 1000000000 )
if all_mem < 7:
    logging.error(f"\033[;31;1mYour System doesn't have enough memory to run the analyis")
    exit(1)

today = date.today()
d1 = today.strftime("%d-%b-%Y")
now = datetime.now()
current_time = now.strftime("%H:%M:%S")

system_info = f"""{d1}    GUAP GUI started at   {current_time}

System platform:   {platform_}
total threads:      {all_threads}
total memory:     {all_mem}

"""

# stores all vars inside a dict
env_vars = {}
inputs = {}

var_inputs_global = {
    'bash_continue': True,
    'snakemake': True,
    'bashdownstream': False,
    'verbose': False,
    'snakemake_dry_run': False,
    'snakemake_dag': False,
    'export-figs': False,
    'condition_name': "condition",
    'name': 'GUAP_Unnamed_run',
    'skip_QC': False,
    'skip_trimmomatic': False,
    'trim_min_length': 50,
    'remove_primers': False,
    'min_length': 50,
    'trunc-f' :0,
    'trunc-r':0,
    'trim-l':0,
    'trim-r':0,
    'maxee-f':4,
    'maxee-r':5,
    'min-overlap':10,
    'chimera-method':"consensus",
    'deblur': False,
    'deblur_trim_length': 100,
    "use_QIIME2": False,
    "choose_classifier": "qiime",
    "train": False
}

# stores system std.err/out
old_stderr = sys.stderr
old_stdout = sys.stdout    

def button_command_obj(txt):
    print(txt)
    print("obj executed")

# class to redirect out
class TextRedirector(object):
    def __init__(self, widget, tag="stdout"):
        super().__init__()
        self.widget = widget
        self.tag = tag
    def write(self, strg):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.widget.configure(state="normal")
        self.widget.insert("end", current_time +"        " + strg + "\n")
        self.widget.configure(state="disabled")
        self.widget.yview(END)

# Main App class
class GUAP_GUI(customtkinter.CTk):
    WIDTH = 1200
    HEIGHT = 700
    

    def __init__(self):
        super().__init__()

        # main UI elements
        self.title("GUAP")
        self.geometry(f"{GUAP_GUI.WIDTH}x{GUAP_GUI.HEIGHT}")
        self.protocol("WM_DELETE_WINDOW", self.on_closing) # call .on_closing() when app gets closed
       
       # create side frame 
        self.side_frame = Side_frame(self, corner_radius=5)
        self.side_frame.grid(row=0, column=0, columnspan=2, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create config_frame
        self.config_frame = config_frame(self,corner_radius=5)
        self.config_frame.grid(row=0, column=2, columnspan=6, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create options_frame
        # self.options_frame = customtkinter.CTkFrame(self,corner_radius=5)
        # self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nsew",padx=5, pady=5)

        # create Statusbar frame
        self.statusbar_frame = status_bar(self,corner_radius=5)
        self.statusbar_frame.grid(row=11, column=0, columnspan=20, rowspan=1, sticky= W+E,padx=5, pady=5)
        global statusbar
        statusbar = self.statusbar_frame

        # create log_frame
        self.log_frame = Log_frame(self)
        self.log_frame.grid(row=0,column=10, columnspan=8, rowspan=11, sticky="nswe",padx=5, pady=5)
        global log_frame
        log_frame = self.log_frame
        #================ configure status bar ===============

        # grid configure
        self.grid_columnconfigure(15,weight=1)
        self.grid_rowconfigure(8,weight=1)

    def on_closing(self, event=0):
        self.destroy()

    def start(self):
        self.mainloop()

    def change_mode(self):
        if self.side_frame.change_theme_switch.get() == 1:
            customtkinter.set_appearance_mode("dark")
            Log_frame.update_log(self.log_frame,"Mode changed to dark")
        else:
            customtkinter.set_appearance_mode("light")
            Log_frame.update_log(self.log_frame,"Mode changed to light")

    def set_options_frame(self,frame):
        self.options_frame = frame
        self.options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nsew",padx=5, pady=5)

class Log_frame(customtkinter.CTkTextbox):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        # self.log_frame = customtkinter.CTkTextbox(parent,corner_radius=5)
        self.insert("insert", system_info + "\n")
        self.configure(state="disabled")  # configure textbox to be read-only

    def grid(self, sticky=("nswe"), **kwargs):
        super().grid(sticky=sticky, **kwargs)

    def update_log(self,txt):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.configure(state="normal")  # configure textbox to be read-only
        self.insert("end", current_time + "     " + str(txt) + "\n")
        self.configure(state="disabled")  # configure textbox to be read-only
        self.yview(END)

class Side_frame(customtkinter.CTkFrame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)

        #================ configure side frame ===============

        self.rowconfigure((0, 1, 2, 3), weight=1)
        self.label_1 = customtkinter.CTkLabel(self,
                                        text="GUAP toolkit",
                                        text_font=("Roboto Medium", -16)) 
        self.label_1.grid(row=0, column=0,padx=5,pady=5)

        self.button_16s = customtkinter.CTkButton(self,
                                                text="16s rRNA", fg_color=("gray75", "gray30"),  # <- custom tuple-color
                                                command=lambda: self.button_command("16s", 
                                                parent.set_options_frame( 
                                                _16s_analysis(parent,corner_radius=5))))
        self.button_16s.grid(row=1, column=0,padx=5,pady=5,sticky="ns")


        self.button_RNA = customtkinter.CTkButton(self,
                                                text="RNAseq", fg_color=("gray75", "gray30"), 
                                                command=lambda: self.button_command("RNA", 
                                                button_command_obj("test")))
        self.button_RNA.grid(row=2, column=0,padx=5,pady=5,sticky="ns")


        self.button_WES = customtkinter.CTkButton(self,
                                                text="WES", fg_color=("gray75", "gray30"), 
                                                command=lambda: self.button_command("WES", 
                                                button_command_obj("test")))
        self.button_WES.grid(row=3, column=0,padx=5,pady=5,sticky="ns")


        self.button_WGS = customtkinter.CTkButton(self,
                                                text="WGS", fg_color=("gray75", "gray30"), 
                                                command=lambda: self.button_command("WGS", 
                                                button_command_obj("test")))
        self.button_WGS.grid(row=4, column=0,padx=5,pady=5,sticky="ns")

        self.change_theme_switch = customtkinter.CTkSwitch(self,
                                                text="Dark Mode",
                                                command=parent.change_mode)

        self.change_theme_switch.grid(row= 8, pady=10, padx=10, sticky="s",rowspan=4)



    def grid(self, sticky=("nswe"), **kwargs):
        super().grid(sticky=sticky, **kwargs)

    def button_command(self, button, obj):
        if button in ["WES", "RNA", "16s", "WGS"]:
            log_frame.update_log(f"{button} started")
            statusbar.update(f"{button} started")
            
        else:
            print(f"ERROR: {button} is not defined!")
        return obj

class config_frame(customtkinter.CTkFrame):

    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)

        #============== configure options frame ===============

        # self.side_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)
        # self.side_frame.columnconfigure((0, 1, 2, 3,4,5,6,7,8), weight=1)

        var_inputs_global['threads'] = all_threads
        var_inputs_global['input'] = StringVar()
        var_inputs_global['output'] = StringVar()
        var_inputs_global['metadata'] = StringVar()


        self.threads_str = StringVar()
        self.threads_str.set(f"Threads = {all_threads}")

        # redirct the analysis to log frame switch
        env_vars["redswitch"] = customtkinter.CTkSwitch(self,
                                                text="stout/err redirect",
                                                command=self.redirect_out)
        env_vars["redswitch"].grid(row= 0, column=2, pady=10, padx=10, sticky="s")


        # frame label
        self.label_2 = customtkinter.CTkLabel(self,
                                        text="Basic configuration",
                                        text_font=("Roboto Medium", -16)) 
        self.label_2.grid(row=0, column=0,padx=5,pady=5)
        # get input dir
        self.input_btn = customtkinter.CTkButton(self,
                                                text="In Dir",
                                                command= lambda:
                                                var_inputs_global['input'].set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )

        self.input_btn.grid(row=1, column=0,sticky="nswe", pady=5, padx=5)

        self.input_label = customtkinter.CTkLabel(self,
                                                  textvariable=var_inputs_global['input'])

        self.input_label.grid(row=1, column=1, sticky="w", columnspan=2)


        # get output dir
        self.output_btn = customtkinter.CTkButton(self,
                                                text="Out Dir",
                                                command= lambda:
                                                var_inputs_global['output'].set(filedialog.askdirectory(initialdir= "~/", title='Please select a directory'))
                                                )

        self.output_btn.grid(row=2, column=0,sticky="nswe", pady=5, padx=5)
        self.output_label = customtkinter.CTkLabel(self,
                                                  textvariable=var_inputs_global['output'])
        self.output_label.grid(row=2, column=1,sticky="w", columnspan=2, pady=5)


        # get metadata file 
        env_vars["metadata_btn"] = customtkinter.CTkButton(self,
                                                text="metadata",
                                                command= lambda:
                                                var_inputs_global['metadata'].set(filedialog.askopenfilename(initialdir= "~/", title='Please select a directory')))
        env_vars["metadata_btn"].grid(row=3, column=0,sticky="nswe", pady=5, padx=5)
        env_vars["metadata_btn"].configure(state="disabled", text="choose analysis to enable")

        self.metadata_LABEL = customtkinter.CTkLabel(self,
                                                  textvariable=var_inputs_global['metadata'])
        self.metadata_LABEL.grid(row=3, column=1,sticky="w", columnspan=2, pady=5)


        # set number of threads
        self.N_threads = customtkinter.CTkSlider(self,from_=4, to=all_threads,number_of_steps=4-all_threads,
                                                command=self.get_N_threads)
        self.N_threads.grid(row=4, column=1, columnspan=2, pady=5, padx=5, sticky="")
        self.N_threads.set(all_threads)
        self.threads_label = customtkinter.CTkLabel(self,
                                                textvariable=self.threads_str)              
        self.threads_label.grid(row=4, column=0, columnspan=1, pady=5, padx=5)

        # set options 
        self.set_snakemake = customtkinter.CTkSwitch(self, 
                                                command= lambda:var_inputs_global['snakemake'] == True if self.set_snakemake.get() == 1 else var_inputs_global['snakemake'] == False ,
                                                text="Use Snakemake",)
        self.set_snakemake.grid(row= 5,column=0,columnspan=1, pady=5, padx=5, sticky="w")
        self.set_snakemake.toggle()

        self.smk_dry_run = customtkinter.CTkSwitch(self,
                                                command= lambda:var_inputs_global['snakemake_dry_run'] == True if self.smk_dry_run.get() == 1 else var_inputs_global['snakemake'] == False ,
                                                text="Snakemake Dry Run",)
        self.smk_dry_run.grid(row= 5,column=1,columnspan=1, pady=5, padx=5, sticky="w")

        self.bash_continue = customtkinter.CTkSwitch(self,
                                                command= lambda:var_inputs_global['bash_continue'] == True if self.bash_continue.get() == 1 else var_inputs_global['snakemake'] == False ,
                                                text="Continue")
        self.bash_continue.toggle()
        self.bash_continue.grid(row= 5,column=2,columnspan=1, pady=5, padx=5, sticky="w")


    def grid(self, sticky=("nswe"), **kwargs):
        super().grid(sticky=sticky, **kwargs)


    def get_N_threads(self,value):
        self.threads_str.set(f"Threads = {int(value)}")
        var_inputs_global['threads'] = value
        status_bar.update(self ="", txt=f"Number of Threads was set to {int(value)}")

    def button_command(self, button, obj):
        if button in ["WES", "RNA", "16s", "WGS"]:
            print(f"{button} pressed.")
            log_frame.update_log(f"{button} started")
            statusbar.update(f"{button} started")
            
        else:
            print(f"ERROR: {button} is not defined!")
        return obj

    def redirect_out(self):
        if env_vars["redswitch"].get() == 1:
            sys.stdout = TextRedirector(log_frame, "stdout")
            sys.stderr = TextRedirector(log_frame, "stderr")
            status_bar.update(self ="", txt="stdout and stderr will be redirected to log screen")

        else:
            sys.stdout = old_stdout
            sys.stderr = old_stderr 
            status_bar.update(self ="", txt="stdout and stderr will be redirected to terminal")

class _16s_analysis(customtkinter.CTkFrame):
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.use_QIIME2 = True
        env_vars["redswitch"].select()
        config_frame.redirect_out(parent)
        env_vars["metadata_btn"].configure(state="normal", text="Metadata") # "normal" (standard) or "disabled" 

        # classifier 
        def optionmenu_callback(choice):
            print("optionmenu dropdown clicked:", choice)

        self.classifier_file = StringVar()

        # create options_frame
        self = customtkinter.CTkFrame(self,corner_radius=5)
        self.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nswe",padx=5, pady=5)
        self.rowconfigure((0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21), weight=1)
        self.columnconfigure((0,1,2,3), weight=1)
        status_bar.update(self ="", txt="16s started")
        log_frame.update_log("""16s analysis
In advanced options you can set:
    1. Dada2 params
    2. deblur min len
    3. trimmomatic min len
    4. naive-bayes classifier params
    5. Remove primers
    6. downstream max-depth
    7. downstream sampling depth

for more info visit:
    URL://@url@info.wiki
""")

        # labels
        self.label_QC = customtkinter.CTkLabel(self, text="QC",
                                        text_font=("Roboto Medium", -16))
        self.label_QC.grid(row=0, column=0,padx=5,pady=5,sticky="w")

        self.label_ASV = customtkinter.CTkLabel(self, text="ASV",
                                        text_font=("Roboto Medium", -16))
        self.label_ASV.grid(row=3, column=0,padx=5,pady=5,sticky="w")

        self.label_class = customtkinter.CTkLabel(self, text="Classifier",
                                        text_font=("Roboto Medium", -16))
        self.label_class.grid(row=0, column=1,padx=5,pady=5)

        self.label_figs = customtkinter.CTkLabel(self, text="Export Figs",
                                        text_font=("Roboto Medium", -16))
        self.label_figs.grid(row=3, column=1,padx=5,pady=5)

        # QC options
        self.skip_QC = customtkinter.CTkCheckBox(self, 
command= lambda: use_QIIME2 == True if self.skip_QC.get() == 1 else use_QIIME2 == False, text="Skip QC")
        self.skip_QC.grid(row= 1,column=0, pady=5, padx=10,sticky="w")
        
        self.skip_trim = customtkinter.CTkCheckBox(self, 
command= lambda: use_QIIME2 == True if self.skip_trim.get() == 1 else use_QIIME2 == False, text="Skip trimming")
        self.skip_trim.grid(row= 2,column=0, pady=5, padx=10,sticky="w")
        self.skip_trim.toggle()
        classifier_file = "test"
        # classifier btn
        self.classifier_btn_label = customtkinter.CTkLabel(self,text="Choose Classifier")
        self.classifier_btn_label.grid(row= 1,column=1, pady=5, padx=0,sticky="w")

        self.classifier_btn = customtkinter.CTkOptionMenu(self,values=["dada2", "QIIME2 naive-bayes"],command=optionmenu_callback)
        self.classifier_btn.grid(row= 1,column=2, pady=5, padx=0,sticky="w")
        self.classifier_btn.set("QIIME2 naive-bayes")  # set initial value
        self.classifier_file_btn = customtkinter.CTkButton(self,text="classifier file",command= lambda:self.classifier_file.set(filedialog.askopenfilename(initialdir= "~/", title='Please select a directory')))
        self.classifier_file_btn.grid(row=2, column=1, pady=5, padx=5,sticky="w")
        self.classifier_file_LABEL = customtkinter.CTkLabel(self,textvariable=classifier_file)
        self.classifier_file_LABEL.grid(row=2, column=2,sticky="w", pady=5)

        # ASV options
        self.use_qiime2 = customtkinter.CTkCheckBox(self, command= lambda: self.use_QIIME2 == True if self.use_qiime2.get() == 1 else self.use_QIIME2 == False, text="Use QIIME2")
        self.use_qiime2.grid(row= 4,column=0, pady=5, padx=10,sticky="w")
        
        self.use_deblur = customtkinter.CTkCheckBox(self, command= lambda: self.use_QIIME2 == True if self.use_deblur.get() == 1 else self.use_QIIME2 == False, text="Use DEBLUR")
        self.use_deblur.grid(row= 5,column=0, pady=5, padx=10,sticky="w")

        self.adv_options_btn = customtkinter.CTkButton(self, 
                                                        fg_color=["gray85", "gray15"],   # <- no fg_color
        text="Advanced Options",command= lambda: _16s_analysis.create_adv_16s(self) )
        self.adv_options_btn.grid(row=21, column=0, padx=15, pady=15,sticky=W+S)

        # export figs 
        self.export_figs_btn = customtkinter.CTkCheckBox(self, command= lambda: self.use_QIIME2 == True if self.export_figs_btn.get() == 1 else self.use_QIIME2 == False, text="Export figs")
        self.export_figs_btn.grid(row= 4,column=1, pady=5, padx=10,sticky="w")
        
        self.downstream_btn = customtkinter.CTkCheckBox(self, command= lambda: self.use_QIIME2 == True if self.downstream_btn.get() == 1 else self.use_QIIME2 == False, text="QIIME2 Downstream")
        self.downstream_btn.grid(row= 5,column=1, pady=5, padx=10,sticky="w")
        # run btn
        self.Run_btn_16s= customtkinter.CTkButton(self, command=lambda: print("RUN analysis"), text="RUN")
        self.Run_btn_16s.grid(row=21,column=3, sticky=E+S, padx=15, pady=15)


    def create_adv_16s(self):
        advanced_options_16s = customtkinter.CTkToplevel(self)
        advanced_options_16s.geometry("600x400")
        advanced_options_16s.title("16s Advanced Options")
        advanced_options_16s.grid_columnconfigure(0,weight=1)
        advanced_options_16s.grid_rowconfigure(0,weight=1)

        advanced_options_16s.Main_frame = customtkinter.CTkFrame(advanced_options_16s,corner_radius=5)
        advanced_options_16s.Main_frame.grid(row=0, column=0, sticky="nswe",padx=5, pady=5)
        advanced_options_16s.Main_frame.rowconfigure((0, 1, 2, 3,4,5,6,7,8,9,10,11,12,13), weight=1)
        advanced_options_16s.Main_frame.columnconfigure((0, 1), weight=1)

        advanced_options_16s.dada_tff_ent = customtkinter.CTkEntry(advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tff_ent.grid(row=2, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tfr_ent = customtkinter.CTkEntry(advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tfr_ent.grid(row=3, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tmf_ent = customtkinter.CTkEntry(advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tmf_ent.grid(row=4, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tmr_ent = customtkinter.CTkEntry(advanced_options_16s.Main_frame,  placeholder_text="0")
        advanced_options_16s.dada_tmr_ent.grid(row=5, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_eff_ent = customtkinter.CTkEntry(advanced_options_16s.Main_frame,  placeholder_text="4")
        advanced_options_16s.dada_eff_ent.grid(row=6, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_efr_ent = customtkinter.CTkEntry(advanced_options_16s.Main_frame,  placeholder_text="5")
        advanced_options_16s.dada_efr_ent.grid(row=7, column=3, padx=5, pady=5,sticky="ew",columnspan=1)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(advanced_options_16s.Main_frame, text="trunclength Forward",)
        advanced_options_16s.dada_tff_label.grid(row=2, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(advanced_options_16s.Main_frame, text="trunclength Reverse")
        advanced_options_16s.dada_tff_label.grid(row=3, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(advanced_options_16s.Main_frame, text="trim length Forward")
        advanced_options_16s.dada_tff_label.grid(row=4, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(advanced_options_16s.Main_frame, text="trim length Reverse")
        advanced_options_16s.dada_tff_label.grid(row=5, column=0, padx=5, pady=5,sticky="w",columnspan=2)

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(advanced_options_16s.Main_frame, text="MaxEE Reverse")
        advanced_options_16s.dada_tff_label.grid(row=6, column=0, padx=5, pady=5,sticky="w",columnspan=2) 

        advanced_options_16s.dada_tff_label = customtkinter.CTkLabel(advanced_options_16s.Main_frame, text="MaxEE Reverse")
        advanced_options_16s.dada_tff_label.grid(row=7, column=0, padx=5, pady=5,sticky="w",columnspan=2) 
        
    def grid(self, sticky=("nswe"), **kwargs):
        super().grid(sticky=sticky, **kwargs)

    def button_command(self, button, obj):
        if button in ["WES", "RNA", "16s", "WGS"]:
            print(f"{button} pressed.")
            log_frame.update_log(f"{button} started")
            statusbar.update(f"{button} started")
            
        else:
            print(f"ERROR: {button} is not defined!")
        return obj


class status_bar(customtkinter.CTkFrame):
    status_strvar = ""
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        status_bar.status_strvar = StringVar()
        status_bar.status_strvar.set("GUAP toolkit initiated")
        self.status_var = customtkinter.CTkLabel(self, text_color= "Grey",
                            textvariable=self.status_strvar,
                            relief=SUNKEN)
        self.status_var.grid(row=0, column=0, padx=1, pady=1)

    def update(self, txt):
        status_bar.status_strvar.set(txt)



if __name__ == "__main__":
    app = GUAP_GUI()
    app.start()