# create list of names boys and grils 
boys = ["ahmed", "mohamed", "ali", "hussien"]
girls = ["sara", "dina", "ola", "mariam"]

# define a function to take user input and make it lower cases
def user_input():
    name = str(input("Please inert a name: ")).lower()
    return name

# define a function that takes a name argument and check if in lists
def evaluate_gender(name):
    if name in boys:
        print("inserted name is a boy")

    elif name in girls:
        print("inserted name is a girl")

    else:
        print("inserted name is unknown")
        learn(name)

    again = input("repeat? (y/n)")

    while again not in ["yes", "y", "no", "n"]:
        again = input("Do you want me to repeat? please answer with y or n").lower()

    if again in ["yes", "y"]:
        evaluate_gender(user_input())
    else:
        print("Thank You :(")

# define a function to add the unknown name to the list
def learn(name_var):
    global boys, girls
    addtonames = input("Do you want me to learn it? (y/n)").lower()
    while addtonames not in ["yes", "y", "no", "n"]:
        addtonames = input("Do you want me to learn it? please answer with y or n").lower()

    if addtonames in ["yes", "y"]:
        gender = input("please specify a gender: (boy/girl)").lower()
        if gender not in ["boy", "boys", "man", "male", "girl", "girls", "woman", "female"]:
            print(f"ERORR: {gender} is not a gender! bye bye  :(")

        elif gender in ["girl", "girls", "woman", "female"]:
            girls.append(name_var)
            print(f"{name_var} add to Girls.")
        else:
            boys += [name_var]
            print(f"{name_var} add to Boys.")

    else:
        print("Thank You :(")





# calls evaluate function and gives user_input function as argument
evaluate_gender(user_input())


