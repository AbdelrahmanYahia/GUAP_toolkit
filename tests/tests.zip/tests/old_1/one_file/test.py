# list of names to check in
boys = ["ahmed", "mohamed", "ali"]
girls = ["sara", "ola", "nor"]

# str1 = "app"
# str2 = "le"

# str3 = str1+str2
# print("this is str 1" + str1)
# print(f"this is str 1 {str1}")

# number  = int(number)  
# name = raw_input.lower()

def user_input():
    global raw_input, number
    raw_input = str(input("please inesrt a name: "))
    number = input(f"please insert {raw_input}'s age: ")
    while number.isnumeric() != True:
        print("Input is not a number please make sure its a number!!!!!!!!!")
        number = input(f"please insert {raw_input}'s age: ")

    return raw_input



def id_gender(name):
    print("function called")
    if name in boys:
        print("inserted name is a boy")
        print(f"Your input: {name} \n Modified input: {name}")

    elif name in girls:
        print("inserted name is a girl")
        print(f"Your input: {name} \n Modified input: {name}")


    else:
        print("inserted name is unknown")
        print(f"Your input: {name} \n Modified input: {name}")


id_gender(user_input())