boys = ["ahmed", "mohamed", "ali", "hussien"]
girls = ["sara", "dina", "ola", "mariam"]

def user_input():
    name = str(input("Please inert a name: ")).lower()
    return name

def evaluate_gender(name):
    if name in boys:
        print("inserted name is a boy")
        return True

    elif name in girls:
        print("inserted name is a girl")
        return True

    else:
        print("inserted name is unknown")
        return False

def learn(name):
    global boys, girls
    addtonames = input("Do you want me to learn it? (y/n)").lower()
    while addtonames not in ["yes", "y", "no", "n"]:
        addtonames = input("Do you want me to learn it? please answer with y or n").lower()

    if addtonames in ["yes", "y"]:
        gender = input("please specify a gender: (boy/girl)").lower()
        if gender not in ["boy", "boys", "man", "male", "girl", "girls", "woman", "female"]:
            print(f"ERORR: {gender} is not a gender! bye bye  :(")

        elif gender in ["girl", "girls", "woman", "female"]:
            girls += [name]
            print(f"{name} add to Girls.")
        else:
            boys += [name]
            print(f"{name} add to Boys.")

    else:
        print("Thank You :(")

    again = input("repeat? (y/n)")
    while again not in ["yes", "y", "no", "n"]:
        again = input("Do you want me to repeat? please answer with y or n").lower()

    if again in ["yes", "y"]:
        pass
    else:
        print("Thank You :(")



name = evaluate_gender(user_input())

while name != True:
    learn(name)


