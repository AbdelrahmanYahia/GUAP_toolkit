#!/usr/bin/python3

# import packages 
import customtkinter
import sys
import os

My_DIR = (os.path.abspath(__file__)).replace("GUI.py","")
sys.path.append(f"{My_DIR}")

import UI_classes 
import _16s
import Vars

# main view class
class analysis_frame(customtkinter.CTkFrame):
    def __init__(self,parent,*args,**kwargs):
        super().__init__(parent, *args, **kwargs)

        self.inputs = {}

        #================ configure side frame ===============

        self.rowconfigure((0, 1, 2, 3), weight=1)

        self.label_1 = customtkinter.CTkLabel(master=self,
                                        text="GUAP toolkit",
                                        text_font=("Roboto Medium", -16)) 
        self.label_1.grid(row=0, column=0,padx=5,pady=5)

        self.button_16s = customtkinter.CTkButton(master=self,
                                                text="16s rRNA", fg_color=("gray75", "gray30"),  # <- custom tuple-color
                                                command=_16s.analysis_16s.bt_16s_event(self,parent))
        self.button_16s.grid(row=1, column=0,padx=5,pady=5,sticky="ns")


        self.button_RNA = customtkinter.CTkButton(master=self,
                                                text="RNAseq", fg_color=("gray75", "gray30"), command=self.button_command)
        self.button_RNA.grid(row=2, column=0,padx=5,pady=5,sticky="ns")


        self.button_WES = customtkinter.CTkButton(master=self,
                                                text="WES", fg_color=("gray75", "gray30"), command=self.button_command)
        self.button_WES.grid(row=3, column=0,padx=5,pady=5,sticky="ns")


        self.button_WGS = customtkinter.CTkButton(master=self,
                                                text="WGS", fg_color=("gray75", "gray30"), command=self.button_command)
        self.button_WGS.grid(row=4, column=0,padx=5,pady=5,sticky="ns")

        self.change_theme_switch = customtkinter.CTkSwitch(master=self,
                                                text="Dark Mode",
                                                command=parent.change_mode)

        self.change_theme_switch.grid(row= 8, pady=10, padx=10, sticky="s",rowspan=4)

    def button_command(self):
        print("Button pressed!")

    def get(self):
        """Retrieve data from form as a dict"""

        # We need to retrieve the data from Tkinter variables
        # and place it in regular Python objects

        data = {}
        for key, widget in self.inputs.items():
            data[key] = widget.get()
        return data

    def reset(self):
        """Resets the form entries"""
        pass

    def get_errors(self):
        """Get a list of field errors in the form"""
        pass






