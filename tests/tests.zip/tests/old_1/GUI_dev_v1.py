#!/usr/bin/python3

# import packages 
import multiprocessing
import tkinter as tk
from tkinter import filedialog
from tkinter import *
import tkinter.messagebox
import customtkinter
import sys
import logging
import psutil
import os
from datetime import datetime
from datetime import date
import platform
from datetime import datetime
import os
import csv
import tkinter as tk
from tkinter import ttk

# set theme in Customtkinter
customtkinter.set_appearance_mode("Light")  # Modes: "System" (standard), "Dark", "Light"
customtkinter.set_default_color_theme("/home/abdelrahman/Desktop/GUAP_GUI/bin/custom_theme.json")

all_threads = multiprocessing.cpu_count()
platform_ = str(platform.system())

use_QIIME2 = False
deblur = False


if all_threads < 4:
    logging.error(f"\033[;31;1mYour System doesn't have enough threads to run the analyis")
    exit(1)
all_mem =int( (psutil.virtual_memory().total ) / 1000000000 )
if all_mem < 7:
    logging.error(f"\033[;31;1mYour System doesn't have enough memory to run the analyis")
    exit(1)

today = date.today()
d1 = today.strftime("%d-%b-%Y")
now = datetime.now()
current_time = now.strftime("%H:%M:%S")

system_info = f"""{d1}    GUAP GUI started at   {current_time}

System platform:   {platform_}
total threads:      {all_threads}
total memory:     {all_mem}

"""

old_stderr = sys.stderr
old_stdout = sys.stdout    


class TextRedirector(object):
    def __init__(self, widget, tag="stdout"):
        super().__init__()
        self.widget = widget
        self.tag = tag
    def write(self, strg):
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        self.widget.configure(state="normal")
        self.widget.insert("end", current_time +"        " + strg + "\n")
        self.widget.configure(state="disabled")
        self.widget.yview(END)


class LabelInput(customtkinter.CTkFrame):
    """A widget containing a label and input together."""

    def __init__(self, parent, label='', input_class=customtkinter.CTkEntry,
                 input_var=None, input_args=None, label_args=None,
                 **kwargs):
        super().__init__(parent, **kwargs)
        input_args = input_args or {}
        label_args = label_args or {}
        self.variable = input_var

        if input_class in (customtkinter.CTkCheckBox, customtkinter.CTkButton, customtkinter.CTkRadioButton):
            input_args["text"] = label
            input_args["variable"] = input_var
        else:
            self.label = customtkinter.CTkLabel(self, text=label, **label_args)
            self.label.grid(row=0, column=0, sticky=(tk.W + tk.E))
            input_args["textvariable"] = input_var

        self.input = input_class(self, **input_args)
        self.input.grid(row=1, column=0, sticky=(tk.W + tk.E))
        self.columnconfigure(0, weight=1)

    def grid(self, sticky=(tk.E + tk.W), **kwargs):
        super().grid(sticky=sticky, **kwargs)

    def get(self):
        if self.variable:
            return self.variable.get()
        elif type(self.input) == customtkinter.CTkText:
            return self.input.get('1.0', END)
        else:
            return self.input.get()

    def set(self, value, *args, **kwargs):
        if type(self.variable) == tk.BooleanVar:
                self.variable.set(bool(value))
        elif self.variable:
                self.variable.set(value, *args, **kwargs)
        elif type(self.input).__name__.endswith('button'):
            if value:
                self.input.select()
            else:
                self.input.deselect()
        elif type(self.input) == customtkinter.CTkText:
            self.input.delete('1.0', END)
            self.input.insert('1.0', value)
        else:
            self.input.delete(0, END)
            self.input.insert(0, value)



class main_ui(customtkinter.CTkFrame):
    """The input form for our widgets"""

    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        # A dict to keep track of input widgets
        self.inputs = {}

        # Build the form
        # recordinfo section

       # create side frame 
        side_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        side_frame.grid(row=0, column=0, columnspan=2, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create config_frame
        config_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        config_frame.grid(row=0, column=2, columnspan=6, rowspan=5, sticky="nsew",padx=5, pady=5)

        # create options_frame
        options_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        options_frame.grid(row=5, column=0, columnspan=8, rowspan=6, sticky="nsew",padx=5, pady=5)

        # create Statusbar frame
        statusbar_frame = customtkinter.CTkFrame(master=self,corner_radius=5)
        statusbar_frame.grid(row=11, column=0, columnspan=20, rowspan=1, sticky= W+E,padx=5, pady=5)

        # create log_frame

        log_frame = customtkinter.CTkTextbox(master=self,corner_radius=5)
        log_frame.grid(row=0, column=10, columnspan=8, rowspan=11, sticky="nswe",padx=5, pady=5)
        log_frame.insert("insert", system_info + "\n")

        log_frame.configure(state="disabled")  # configure textbox to be read-only
        # grid configure
        self.grid_columnconfigure(15,weight=1)
        self.grid_rowconfigure(8,weight=1)


        #=============== pop. side frame ==================
        self.inputs['input'] = LabelFrame(
            side_frame, "Input",
            input_class=customtkinter.CTkButton,
            input_args={"command": lambda: print("test")}
            )
        self.inputs['input'].grid(row=0,column=0)
        
        self.inputs['output'] = LabelFrame(
            side_frame, "Output",
            input_class=customtkinter.CTkButton,
            input_args={"command": lambda: print("test")}
            )
        self.inputs['output'].grid(row=1,column=0)

        def get(self):
            data = {}
            for key,widget in self.inputs.items():
                data[key] = widget.get()

            return data
        
        def reset(self):
            # clear all values
            for widget in self.inputs.values():
                widget.set('')

class Application(customtkinter.CTk):
    WIDTH = 1200
    HEIGHT = 700

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.title("GUAP")
        self.geometry(f"{Application.WIDTH}x{Application.HEIGHT}")
        # self.protocol("WM_DELETE_WINDOW", self.on_closing) # call .on_closing() when app gets closed


        self.main_UI = main_ui(self)
        self.recordform.grid(row=0, padx=10)

        self.savebutton = customtkinter.CTkButton(self, text="Save", command=self.on_save)
        self.savebutton.grid(sticky=tk.E, row=2, padx=10)


        self.records_saved = 0

    def on_save(self):
        """Handles save button clicks"""

        # For now, we save to a hardcoded filename with a datestring.
        # If it doesnt' exist, create it,
        # otherwise just append to the existing file
        datestring = datetime.today().strftime("%Y-%m-%d")
        filename = "abq_data_record_{}.csv".format(datestring)
        newfile = not os.path.exists(filename)

        data = self.main_ui.get()

        with open(filename, 'a') as fh:
            csvwriter = csv.DictWriter(fh, fieldnames=data.keys())
            if newfile:
                csvwriter.writeheader()
            csvwriter.writerow(data)

        self.records_saved += 1
        self.status.set(
            "{} records saved this session".format(self.records_saved))
        self.main_ui.reset()


if __name__ == "__main__":

    app = Application()
    app.mainloop()




